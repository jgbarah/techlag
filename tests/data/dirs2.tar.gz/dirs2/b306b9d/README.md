# techlag
Scripts and info for this idea about technical lag in software compilations
